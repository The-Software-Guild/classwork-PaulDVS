package com.sujata.service;

public interface DummyService {
	
	public String greet();
	public int sum(int number1,int number2);

}
